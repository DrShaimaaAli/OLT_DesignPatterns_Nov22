package Visitor;

public abstract class CourseFormatterVisitor {
	abstract void FormateOnlineCourse(OnlineCourse course);
	abstract void FormateInPersonCourse(InPersonCourse course);
}
