package Visitor;

public class OnlineCourse extends Course{

	public String getCourseContent()
	{
		return "Content";
	}
	
	 void accept(CourseFormatterVisitor visitor)
	 {
		 visitor.FormateOnlineCourse(this);
	 }
	
}
