package Visitor;

public class PlainTextFromatter  extends CourseFormatterVisitor {
	 void FormateOnlineCourse(OnlineCourse course)
	 {
		 course.getCourseContent();
		 // generate plain text format
	 }
	 void FormateInPersonCourse(InPersonCourse course)
	 {
		 course.getCourseOutlines();
		 // generate plain text format
	 }
}
