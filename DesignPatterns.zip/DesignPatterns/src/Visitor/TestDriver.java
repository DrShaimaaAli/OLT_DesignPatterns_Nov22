package Visitor;

public class TestDriver {
	public static void main(String[] args) {
		OnlineCourse course = new OnlineCourse();
		
		course.accept(new GraphicsFormatterVisitor());
		course.accept(new PlainTextFromatter());
	}
}
