package Visitor;

public abstract class Course {
	abstract void accept(CourseFormatterVisitor visitor);
}
