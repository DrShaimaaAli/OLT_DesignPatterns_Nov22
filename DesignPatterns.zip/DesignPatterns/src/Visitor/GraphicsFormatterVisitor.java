package Visitor;

public class GraphicsFormatterVisitor extends CourseFormatterVisitor {
	 void FormateOnlineCourse(OnlineCourse course)
	 {
		 course.getCourseContent();
		 // generate graphics formatter
	 }
	 void FormateInPersonCourse(InPersonCourse course)
	 {
		 course.getCourseOutlines();
		 // generate graphics formatter
	 }

}
