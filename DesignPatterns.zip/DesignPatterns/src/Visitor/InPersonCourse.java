package Visitor;

public class InPersonCourse {

	public String getCourseOutlines() {
		return "Course outlines";
	}
	
	void accept(CourseFormatterVisitor visitor)
	 {
		 visitor.FormateInPersonCourse(this);
	 }
}
