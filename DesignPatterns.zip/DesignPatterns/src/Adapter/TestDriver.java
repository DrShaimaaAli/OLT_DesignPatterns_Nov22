package Adapter;

public class TestDriver {
	public static void apiFunction_client(API_original api)
	{
		api.service();
	}
	
	public static void main(String[] args) {
		API_original api= new API_adapter(new API_updated());
		
		apiFunction_client(api);
	}
}
