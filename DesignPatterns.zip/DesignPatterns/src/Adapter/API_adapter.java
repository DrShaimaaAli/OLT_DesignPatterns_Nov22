package Adapter;

public class API_adapter extends API_original {

	API_updated updated_api;
	public API_adapter(API_updated updated_api)
	{
		this.updated_api = updated_api;
	}
	
	public void service()
	{
		updated_api.updatedService();
	}
}
