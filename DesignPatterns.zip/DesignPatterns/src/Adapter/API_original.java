package Adapter;

public class API_original {

	public void service()
	{
		System.out.println("Original Service");
	}
}
