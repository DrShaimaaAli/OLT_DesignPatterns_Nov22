package Adapter;

public class API_updated {

	public void updatedService()
	{
		// internal implemntation of the service it self has to be updated
		System.out.println("Updated Service");
	}
}
