
public class UserPrefs {

	private static UserPrefs singleton;
	
	private UserPrefs(){}
	
	public static UserPrefs getInstance()
	{
		if (singleton == null)
			singleton = new UserPrefs();
		return singleton;
	}
	
	
	private String prefColor;
	private String prefFont;
	
	String getPrefColor() {
		return prefColor;
	}
	void setPrefColor(String prefColor) {
		this.prefColor = prefColor;
	}
	String getPrefFont() {
		return prefFont;
	}
	void setPrefFont(String prefFont) {
		this.prefFont = prefFont;
	}
	
}
