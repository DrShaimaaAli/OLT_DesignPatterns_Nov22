package AbstractFactory;

public class DesktopWidgetFactory extends WidgetFactory{

	public  Window windowFactory()
	{
		return new Window_Desktop();
	}
	public  Scrollbar scrollbarFactory()
	{
		return new Scrollbar_Desktop();
	}
}
