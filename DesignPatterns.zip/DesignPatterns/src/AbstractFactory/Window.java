package AbstractFactory;

public abstract class Window {

	public  abstract void display();
}
