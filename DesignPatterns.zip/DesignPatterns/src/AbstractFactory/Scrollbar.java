package AbstractFactory;

public abstract class Scrollbar {

	public abstract void setLocation(int loc);
}
