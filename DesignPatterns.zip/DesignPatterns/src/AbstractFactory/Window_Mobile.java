package AbstractFactory;

public class Window_Mobile extends Window{

	public void display()
	{
		System.out.println("A Mobile Window is displayed");
	}
}
