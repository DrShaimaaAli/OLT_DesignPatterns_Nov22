package AbstractFactory;

public class Scrollbar_Desktop extends Scrollbar{

	public void setLocation(int loc) {
		System.out.println("Desktop Scrollbar is set to: " + loc);
	}
}
