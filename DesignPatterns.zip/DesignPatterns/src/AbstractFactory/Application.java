package AbstractFactory;

public abstract class Application {
	Window window;
	Scrollbar scrollbar;
	WidgetFactory factory;
	
	public void openWindow()
	{
		window  = factory.windowFactory();
		scrollbar = factory.scrollbarFactory(); 
		
		window.display();
		scrollbar.setLocation(0);
	}
	
}
