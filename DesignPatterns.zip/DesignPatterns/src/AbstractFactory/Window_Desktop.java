package AbstractFactory;

public class Window_Desktop extends Window {

	public void display()
	{
		System.out.println("A Desktop Window is displayed");
	}
	
}
