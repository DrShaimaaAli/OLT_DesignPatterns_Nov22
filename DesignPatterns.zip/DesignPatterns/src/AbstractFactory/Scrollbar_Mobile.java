package AbstractFactory;

public class Scrollbar_Mobile extends Scrollbar{

	public void setLocation(int loc) {
		System.out.println("Mobile Scrollbar is set to: " + loc);
	}
}
