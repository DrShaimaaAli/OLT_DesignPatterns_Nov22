package AbstractFactory;

public class MobileWidgetFactory extends WidgetFactory{
	public  Window windowFactory()
	{
		return new Window_Mobile();
	}
	public  Scrollbar scrollbarFactory()
	{
		return new Scrollbar_Mobile();
	}
}
