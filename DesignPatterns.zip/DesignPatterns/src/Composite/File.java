package Composite;

public class File extends ParentFile{

	File (String fileName) {
		super(fileName);
	}
	
	public void openFile()
	{
		System.out.println("File:" + getFileName());
		super.openFile();
	}
	
	public void closeFile()
	{
		System.out.println("File:" + getFileName());
		super.closeFile();
	}
}
