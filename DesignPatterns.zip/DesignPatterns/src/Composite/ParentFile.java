package Composite;

public class ParentFile {

	private String fileName;
	public ParentFile(String fileName) {
		this.fileName = fileName;
	}
	
	public void openFile()
	{
		System.out.println("File is open");
	}
	
	public void closeFile()
	{
		System.out.println("File is closed");
	}

	String getFileName() {
		return fileName;
	}

	void setFileName(String fileName) {
		this.fileName = fileName;
	}
}
