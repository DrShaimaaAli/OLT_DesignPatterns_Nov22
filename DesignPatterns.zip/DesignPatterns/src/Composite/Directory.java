package Composite;

import java.util.ArrayList;

public class Directory extends ParentFile{
	
	ArrayList<ParentFile> children = new ArrayList<>();
	
	Directory (String fileName) {
		super(fileName);
	}
	public void addChild(ParentFile file)
	{
		children.add(file);
	}
	public void removeChild(ParentFile file)
	{
		children.remove(file);
	}
	
	public void openFile()
	{
		System.out.println("File:" + getFileName());
		super.openFile();
		for (ParentFile f : children )
			System.out.println(">>>> File:" + f.getFileName());
	}
}
