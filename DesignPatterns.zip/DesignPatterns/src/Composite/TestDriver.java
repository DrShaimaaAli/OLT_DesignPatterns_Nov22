package Composite;

public class TestDriver {
	public static void main(String[] args) {
		// OLT
		// -> DesignPatterns (dir)
		// 	  -> Day1 (dir)
		//		--> patern 1 (file)
		//		--> pattern 2 (file)
		// -> instructorInfo (file)
		
		Directory olt = new Directory("OLT");
			Directory DP = new Directory("DesignPatterns");
				DP.addChild(new File("patern 1"));
				DP.addChild(new File("patern 1"));
			ParentFile info = new File("instructorInfo");
		olt.addChild(DP);
		olt.addChild(info);
		
		olt.openFile();
		DP.openFile();
	}
}
