package Command;

public class EmailReciever extends Reciever {

	
	 void send() {
		 System.out.println(getMessage() + " was sent in an email");
	 }
	 void read()
	 {
		 // logic of openeing email to read
	 }

}
