package Command;

public class ReadCommand extends Command{

	void execute() {
		// common logic for the send command
		getReciever().read();
		//clean-up after the action was performed
	}

}
