package Command;

public abstract class Reciever {

	private String message;
	
	abstract void send();
	abstract void read();
	
	String getMessage() {
		return message;
	}
	void setMessage(String message) {
		this.message = message;
	}
}
