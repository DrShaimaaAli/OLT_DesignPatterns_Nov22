package Command;

public class SMSReciever extends Reciever {

	
	 void send() {
		 System.out.println(getMessage() + " was sent in an SMS");
	 }
	 void read()
	 {
		 // logic of openeing SMS to read
	 }

}
