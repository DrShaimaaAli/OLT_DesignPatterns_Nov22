package Command;

import java.util.ArrayList;

public class Client_TestDrive {

	public static void main (String[] args)
	{
		// Two commands
		// send - read
		
		// Three receivers with corresponding actions 
		// email, sms and notification
		
		
		SendCommand emailSend = new SendCommand();
		EmailReciever emailReciever = new EmailReciever();
		emailSend.setReciever(emailReciever);
		
		SendCommand SMSSend = new SendCommand();
		SMSReciever smsReciever = new SMSReciever();
		SMSSend.setReciever(smsReciever);
		
		ReadCommand emailRead = new ReadCommand();
		emailSend.setReciever(emailReciever);
		
		SendCommand SMSRead = new SendCommand();
		SMSSend.setReciever(smsReciever);
		
		
		
		//The invoker would need the references to the command object (e.g. Context Menu)
		ArrayList<Command> emailContexMenu_Invoker = new ArrayList<>();
		emailContexMenu_Invoker.add(emailSend);
		emailContexMenu_Invoker.add(emailRead);
		
		ArrayList<Command> smsContexMenu_Invoker = new ArrayList<>();
		smsContexMenu_Invoker.add(SMSSend);
		smsContexMenu_Invoker.add(SMSRead);
		
		// When a command is invoked it will be executed and call the corresponding action of the receiver
		emailContexMenu_Invoker.get(0).execute();
	}
}
