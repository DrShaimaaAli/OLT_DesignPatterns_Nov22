package Command;

public class SendCommand extends Command{

	void execute() {
		// common logic for the send command
		getReciever().send();
		//clean-up after the action was performed
	}
}
