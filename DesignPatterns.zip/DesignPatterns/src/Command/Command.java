package Command;

public abstract class Command {

	private Reciever reciever;
	
	abstract void execute();

	Reciever getReciever() {
		return reciever;
	}

	void setReciever(Reciever reciever) {
		this.reciever = reciever;
	}
	
}
