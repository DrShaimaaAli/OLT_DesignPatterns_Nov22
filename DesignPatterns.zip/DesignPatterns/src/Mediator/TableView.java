package Mediator;

public class TableView extends Colleague{
	private String state;

	TableView(Mediator mediator)
	{
		super(mediator);
	}
	
	String getState() {
		return state;
	}

	void setState(String state) {
		this.state = state;
		
		mediator.Notify(this);
	}
	
	 void update(Colleague  updatedColleague)
	 {
		 state = updatedColleague.getState();
		 /// do something with it
		 System.out.println("TableView object was updated: " + state);
	 }

}
