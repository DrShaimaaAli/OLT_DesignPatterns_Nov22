package Mediator;

public class Data extends Colleague{
	private String state;

	Data(Mediator mediator)
	{
		super(mediator);
	}
	
	String getState() {
		return state;
	}

	void setState(String state) {
		this.state = state;
		
		mediator.Notify(this);
	}
	
	 void update(Colleague  updatedColleague)
	 {
		 state = updatedColleague.getState();
		 /// do something with it
		 System.out.println("Data object was updated: " + state);
	 }
	
}
