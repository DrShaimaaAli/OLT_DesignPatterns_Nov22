package Mediator;

public abstract class Colleague {

	Mediator mediator;
	Colleague(Mediator mediator)
	{
		this.mediator = mediator;
	}
	
	abstract void update(Colleague  updatedColleague);
	abstract String getState();
	
}
