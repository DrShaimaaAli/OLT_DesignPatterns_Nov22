package Mediator;

import java.util.ArrayList;

public class Mediator {
	ArrayList<Colleague> colleagues = new ArrayList<>();
	
	public void addColleague(Colleague c)
	{
		colleagues.add(c);
	}
	public void removeColleague(Colleague c)
	{
		colleagues.remove(c);
	}
	
	public void Notify(Colleague updatedColleague)
	{
		for (Colleague c: colleagues )
			c.update(updatedColleague);
	}
}
