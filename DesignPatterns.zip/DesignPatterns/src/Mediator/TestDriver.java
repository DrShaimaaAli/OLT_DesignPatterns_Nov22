package Mediator;

public class TestDriver {
	public static void main(String[] args) {
		Mediator med = new Mediator();
		
		Data d = new Data(med);
		med.addColleague(d);
		
		TableView t = new TableView(med);
		med.addColleague(t);
		
		d.setState("ABC");
		System.out.println("===========================");
		t.setState("XYZ");
	}
}
