package Observer;

public class Data extends Subject{
	private String data;

	String getState()
	{
		return getData();
	}
	
	String getData() {
		return data;
	}

	void setData(String data) {
		this.data = data;
		Notify();
	}
	
}
