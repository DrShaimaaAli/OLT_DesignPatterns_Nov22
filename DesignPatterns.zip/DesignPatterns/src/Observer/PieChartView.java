package Observer;

public class PieChartView extends Observer{

	public void update(Subject s) {
		System.out.println("PieChart View was updated: " +s.getState());
	}

}
