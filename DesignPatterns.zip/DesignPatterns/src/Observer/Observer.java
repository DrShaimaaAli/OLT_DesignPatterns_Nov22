package Observer;

public abstract class Observer {
	abstract public void update(Subject s);
}
