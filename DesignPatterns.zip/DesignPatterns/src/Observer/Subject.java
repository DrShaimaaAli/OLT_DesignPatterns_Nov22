package Observer;

import java.util.ArrayList;

public abstract class Subject {
	ArrayList<Observer> observers = new ArrayList<>();
	
	abstract String getState();
	
	public void attach(Observer o)
	{
		observers.add(o);
	}
	public void dettach(Observer o)
	{
		observers.remove(o);
	}
	
	public void Notify()
	{
		for(Observer o: observers)
			o.update(this);
	}
}
