package Observer;

public class TestDriver {
	public static void main(String[] args) {
		
		Data d = new Data();
		d.attach(new TableView());
		d.attach(new TableView());
		
		d.attach(new PieChartView());
		d.attach(new PieChartView());
		
		d.setData("A");
		System.out.println("=======================");
		d.setData("B");
		System.out.println("=======================");
		d.setData("C");
		
	}
}
