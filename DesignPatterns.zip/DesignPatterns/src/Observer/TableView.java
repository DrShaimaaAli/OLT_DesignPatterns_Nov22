package Observer;

public class TableView extends Observer{

	public void update(Subject s) {
		System.out.println("TableView was updated: " +s.getState());
	}
}
