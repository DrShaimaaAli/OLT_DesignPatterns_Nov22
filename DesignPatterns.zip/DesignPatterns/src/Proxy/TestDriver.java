package Proxy;

public class TestDriver {
	
	public static void displayDoc_client(AbstractDocument doc)
	{
		doc.download();
	}
	public static void main(String[] args) {
		Document doc = new Document();
		doc.addText("ABC");
		doc.addText("XYZ");
		doc.addText("LMN");
		
		doc.addImage("Image 1");
		doc.addImage("Image 2");
		doc.addImage("Image 3");
		
		displayDoc_client(doc);
		
		System.out.println("=======================");
		displayDoc_client(new ProxyDocument(doc));
		
	}
}
