package Proxy;

public abstract class AbstractDocument {

	abstract void download();
}
