package Proxy;

import java.util.ArrayList;

public class Document extends AbstractDocument{
	ArrayList<String> text = new ArrayList<>();
	ArrayList<String> images = new ArrayList<>();
	
	public void addText(String txt)
	{
		text.add(txt);
	}
	
	public void addImage(String img)
	{
		images.add(img);
	}
	
	public void download()
	{
		for(String t : text)
			System.out.println(t);
		
		for(String img : images)
			System.out.println(img);
		
	}
}
