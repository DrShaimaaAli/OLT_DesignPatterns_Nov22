package Proxy;

public class ProxyDocument extends AbstractDocument{

	Document doc;
	ProxyDocument(Document doc)
	{
		super();
		this.doc = doc;
	}
	
	public void download()
	{
		for(String t : doc.text)
			System.out.println(t);
		
		for(String img : doc.images)
		{
			System.out.println(img);
			System.out.println("Delay .........");
			// wait for tirgger or time span
		}
		
	}
}
