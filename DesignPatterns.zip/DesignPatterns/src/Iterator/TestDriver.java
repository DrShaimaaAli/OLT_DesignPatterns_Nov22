package Iterator;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestDriver {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
		list.add("A");
		list.add("B");
		list.add("C");
		
		ListIterator iterator = list.listIterator();
		
		while(iterator.hasNext())
		{
			String item = (String)iterator.next();
			System.out.println(item);
		}
	}
}
