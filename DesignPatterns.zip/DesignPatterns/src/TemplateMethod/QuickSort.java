package TemplateMethod;

public class QuickSort extends DividAndConqure{
	
	 void divide() {
		 // divide the list around a pivot
	 }
	 void conqure()
	 {}
	 
	 void combine()
	 {}
}

