package TemplateMethod;

public abstract class DividAndConqure {

	public void sort()
	{
		divide();
		conqure();
		combine();
	}
	
	abstract void divide();
	abstract void conqure();
	abstract void combine();
}
