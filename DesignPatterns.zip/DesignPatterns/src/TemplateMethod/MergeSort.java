package TemplateMethod;

public class MergeSort extends DividAndConqure{
	
	 void divide() {
		 // divide the list into two halves
	 }
	 void conqure()
	 {}
	 
	 void combine()
	 {}
}


