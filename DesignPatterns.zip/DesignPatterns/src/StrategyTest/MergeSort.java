package StrategyTest;

import java.util.List;

public class MergeSort extends SortStrategy{

	public void sort(List list)
	{
		// Merge sort logic
	}

}
