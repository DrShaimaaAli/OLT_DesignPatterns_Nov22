package StrategyTest;

import java.util.List;

public class BubbleSort extends SortStrategy{

	public void sort(List list)
	{
		// bubble sort logic
	}
	
}
