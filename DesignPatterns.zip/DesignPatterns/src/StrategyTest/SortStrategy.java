package StrategyTest;

import java.util.List;

public abstract class SortStrategy {

	abstract void sort(List list);
}
