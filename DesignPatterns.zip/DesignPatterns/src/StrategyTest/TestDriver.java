package StrategyTest;

import java.util.ArrayList;

public class TestDriver {

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		
		list.add(4);
		list.add(5);
		list.add(10);
		list.add(18);
		
	
		// We need to sort these numbers
	    // so we'll need to create an object of one of the concrete sorting strategies 
		SortStrategy sortStrategy = new MergeSort();
		sortStrategy.sort(list);
	}
}
