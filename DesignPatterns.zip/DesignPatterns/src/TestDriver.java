import java.util.ArrayList;

public class TestDriver {

	public static void main(String[] args) {
		/*
		UserPrefs pref1 = UserPrefs.getInstance();
		pref1.setPrefColor("Red");
		
		UserPrefs pref2 = UserPrefs.getInstance();
		pref2.setPrefColor("Green");
		
		
		System.out.println("Pref1-Color: "+ pref1.getPrefColor() + " Pref2-Color: "+ pref2.getPrefColor());
		*/
		
		ArrayList<ArrayList<String>> list = new ArrayList<>();
		list.add(new ArrayList<>());
		list.add(new ArrayList<>());
		
		list.get(0).add("ABC");
		list.get(1).add("XYZ");
		
		
		ArrayList<ArrayList<String>> shallowCopy = (ArrayList) list.clone();
		
		list.add(new ArrayList<>());
		list.get(2).add("ZZZ");
		
		shallowCopy.add(new ArrayList<>());
		shallowCopy.get(2).add("XXXX");
		
		
		System.out.println("Original List "+list);
		System.out.println("Shallow copy "+ shallowCopy);
		
		System.out.println("==================");
		list.get(0).add("AAAAA");
		
		System.out.println("Original List "+list);
		System.out.println("Shallow copy "+ shallowCopy);

	}
}
