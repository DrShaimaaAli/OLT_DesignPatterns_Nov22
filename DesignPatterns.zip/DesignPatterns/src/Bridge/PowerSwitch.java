package Bridge;

public class PowerSwitch {

	private SectionedLightes lightes;
	
	
	public void on()
	{
		lightes.turnSectionedLightesOn();
	}
	
	public void off()
	{
		lightes.turnSectionedLightesOff();
	}
	
	SectionedLightes getLightes() {
		return lightes;
	}
	void setLightes(SectionedLightes lightes) {
		this.lightes = lightes;
	}
}
