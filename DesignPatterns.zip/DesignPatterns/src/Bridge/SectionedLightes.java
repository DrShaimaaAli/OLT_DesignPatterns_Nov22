package Bridge;

public abstract class SectionedLightes {

	public abstract void turnSectionedLightesOn();
	public abstract void turnSectionedLightesOff();
}
