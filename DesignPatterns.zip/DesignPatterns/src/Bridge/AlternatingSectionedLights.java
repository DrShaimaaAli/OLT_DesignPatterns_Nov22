package Bridge;

public class AlternatingSectionedLights extends SectionedLightes {

	public  void turnSectionedLightesOn() {
		System.out.println("Alternating Sectioned lightes turned ON");
	}
	
	public  void turnSectionedLightesOff(){
		System.out.println("Alternating Sectioned lightes turned OFF");
	}

}
