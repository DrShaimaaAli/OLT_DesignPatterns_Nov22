package Bridge;

public class RegularSectionedLights extends SectionedLightes {

	public  void turnSectionedLightesOn() {
		System.out.println("Regular Sectioned lightes turned ON");
	}
	
	public  void turnSectionedLightesOff(){
		System.out.println("Regular Sectioned lightes turned OFF");
	}
}
