package Bridge;

public class TestDriver {
	
	public static void handlePower_client(PowerSwitch power)
	{
		// When the user chooses on
		power.on();
		
		// When the user chooses off
		power.off();
	}
	
	public static void main(String[] args) {
		
		SectionedLightes[] setOfLights = new SectionedLightes[2];
		
		setOfLights[0]= new RegularSectionedLights(); 
		setOfLights[1] = new AlternatingSectionedLights();
		
		PowerSwitch powerSwitch = new PowerSwitch();
		for (int i = 0; i < setOfLights.length; i++) {
			powerSwitch.setLightes(setOfLights[i]);
			handlePower_client(powerSwitch);
			
			System.out.println("======================================");
		}
		
		powerSwitch = new TimedPowerSwitch();
		for (int i = 0; i < setOfLights.length; i++) {
			powerSwitch.setLightes(setOfLights[i]);
			handlePower_client(powerSwitch);
			
			System.out.println("======================================");
		}
	}
}
