package Bridge;

public class TimedPowerSwitch extends PowerSwitch {

	public void configureTime() {}
	
	public void on() {
		// at the given
		System.out.println("Time Met>>");
		super.on();
	}
	
	public void off() {
		// at the given
		System.out.println("Time Met>>");
		super.off();
	}
	
	
}
