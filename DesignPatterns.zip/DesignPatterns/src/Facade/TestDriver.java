package Facade;

public class TestDriver {
	public static void main(String[] args) {
		FacadAPI api = new FacadAPI(new ServiceAPI_A(), new ServiceAPI_B());
		api.download();
		api.encrypt();
		api.dencrypt();
		api.upload("ABC");
		
	}
}
