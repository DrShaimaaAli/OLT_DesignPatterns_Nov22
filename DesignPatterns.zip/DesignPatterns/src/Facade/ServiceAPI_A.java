package Facade;

public class ServiceAPI_A {

	public void apiA_downloadData()
	{
		System.out.println("Data Downloaded through API A");
	}
	
	public void apiA_uploadData(String data)
	{
		System.out.println("Data "+ data + " uploaded through API A");
	}
	
	
}
