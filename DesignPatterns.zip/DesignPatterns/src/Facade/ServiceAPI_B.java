package Facade;

public class ServiceAPI_B {

	public void encrypt()
	{
		System.out.println("Encryption done through API B");
	}
	
	public void dencrypt()
	{
		System.out.println("Dencryption done through API B");
	}
}
