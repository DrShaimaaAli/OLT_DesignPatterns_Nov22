package Facade;

public class FacadAPI {
	ServiceAPI_A apiA;
	ServiceAPI_B apiB;
	
	FacadAPI(ServiceAPI_A apiA,	ServiceAPI_B apiB)
	{
		this.apiA = apiA;
		this.apiB = apiB;
	}
	
	public void download()
	{
		apiA.apiA_downloadData();
	}
	
	public void upload(String data)
	{
		apiA.apiA_uploadData(data);;
	}
	
	public void encrypt()
	{
		apiB.encrypt();
	}
	
	public void dencrypt()
	{
		apiB.dencrypt();
	}
}
