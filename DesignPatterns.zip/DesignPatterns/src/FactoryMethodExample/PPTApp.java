package FactoryMethodExample;

public class PPTApp extends OfficeApp{

	public Document documentFactory()
	{
		return new PPTDocument();
	}
}
