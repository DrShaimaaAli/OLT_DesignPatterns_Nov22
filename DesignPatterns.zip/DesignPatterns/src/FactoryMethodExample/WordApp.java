package FactoryMethodExample;

public class WordApp extends OfficeApp {

	public Document documentFactory()
	{
		return new WordDocument();
	}
}
