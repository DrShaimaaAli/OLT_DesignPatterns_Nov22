package FactoryMethodExample;

public class PPTDocument extends Document{

	public void open()
	{
		System.out.println("A PPT Document opened");
	}
}
