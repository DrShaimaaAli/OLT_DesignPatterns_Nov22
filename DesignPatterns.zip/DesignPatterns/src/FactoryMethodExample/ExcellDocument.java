package FactoryMethodExample;

public class ExcellDocument extends Document{

	public void open()
	{
		System.out.println("A Excel Document opened");
	}
}
