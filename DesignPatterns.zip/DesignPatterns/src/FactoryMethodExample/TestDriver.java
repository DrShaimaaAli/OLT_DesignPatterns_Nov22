package FactoryMethodExample;

public class TestDriver {
	public static void main(String[] args) {
		OfficeApp app= new WordApp();
		app.newDocument();
		
		app= new PPTApp();
		app.newDocument();
		
		app= new ExcellApp();
		app.newDocument();
	}
}
