package FactoryMethodExample;

public abstract class Document {

	public abstract void open();
}
