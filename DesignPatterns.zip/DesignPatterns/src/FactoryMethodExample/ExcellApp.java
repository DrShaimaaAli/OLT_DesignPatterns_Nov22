package FactoryMethodExample;

public class ExcellApp extends OfficeApp{

	public Document documentFactory()
	{
		return new ExcellDocument();
	}
}
