package FactoryMethodExample;

public class WordDocument extends Document{

	public void open()
	{
		System.out.println("A Word Document opened");
	}
}
