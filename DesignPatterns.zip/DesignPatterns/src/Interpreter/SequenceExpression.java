package Interpreter;

public class SequenceExpression extends RegularExpression {

	private RegularExpression firstExpression;
	private RegularExpression secondExpression;
	
	boolean isMatch(String toMatch)
	{
		boolean match = getFirstExpression().isMatch(toMatch) 
				      && getSecondExpression().isMatch(toMatch); //and the order matches
		return match;
	}

	RegularExpression getFirstExpression() {
		return firstExpression;
	}

	void setFirstExpression(RegularExpression firstExpression) {
		this.firstExpression = firstExpression;
	}

	RegularExpression getSecondExpression() {
		return secondExpression;
	}

	void setSecondExpression(RegularExpression secondExpression) {
		this.secondExpression = secondExpression;
	}
}
