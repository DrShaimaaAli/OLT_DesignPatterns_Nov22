package Interpreter;

public class LiteralExpression extends RegularExpression{
	private String literal;
	
	boolean isMatch(String toMatch) {
		boolean match= false;
		// either a or b
		match = toMatch.contains(literal); //|| toMatch.contains("b");
		return match;
	}

	String getLiteral() {
		return literal;
	}

	void setLiteral(String literal) {
		this.literal = literal;
	}
}
