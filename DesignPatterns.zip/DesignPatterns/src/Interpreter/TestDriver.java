package Interpreter;

public class TestDriver {
	public static void main(String[] args) {

		// ( a & b )
		
		SequenceExpression parent = new SequenceExpression();
		LiteralExpression first = new LiteralExpression();
			first.setLiteral("a");
		LiteralExpression second = new LiteralExpression();
			second.setLiteral("b");
			
		parent.setFirstExpression(first);
		parent.setSecondExpression(second);
		
		parent.isMatch("ab");
		parent.isMatch("b");
		
	}
}
