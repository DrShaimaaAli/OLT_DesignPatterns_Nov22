package BuilderExample;

public class RegularCoffeeBuilder extends CoffeeBuilder{

	public  void addMilk()
	{
		cup.coffeeOrder.add("Milk");
	}
	public  void addCream()
	{}
	public  void addSugar()
	{
		cup.coffeeOrder.add("Sugar");
	}
	public  void addCoffee()
	{
		cup.coffeeOrder.add("Midum Roast Coffee");
	}
}
