package BuilderExample;

public abstract class CoffeeBuilder {

	CoffeeCup cup;
	public CoffeeBuilder()
	{
		cup = new CoffeeCup();
	}
	
	public CoffeeCup getResult()
	{
		return cup;
	}
	
	public abstract void addMilk();
	public abstract void addCream();
	public abstract void addSugar();
	public abstract void addCoffee();
}
