package BuilderExample;

import java.util.ArrayList;

public class CoffeeCup {
	public ArrayList<String> coffeeOrder = new ArrayList<String>();
}
