package BuilderExample;

public class TestDrive {
	public static void main(String[] args) {
		Director d= new Director();
		CoffeeBuilder build = new DoubleDoubleCoffeeBuilder();
		
		d.prepareCoffee(build);
		
		CoffeeCup cup = build.getResult();
		
		System.out.println(cup.coffeeOrder);
		
		
		build = new RegularCoffeeBuilder();
		d.prepareCoffee(build);
		
		cup = build.getResult();
		
		System.out.println(cup.coffeeOrder);
	}
}
