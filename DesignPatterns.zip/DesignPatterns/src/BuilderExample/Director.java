package BuilderExample;

public class Director {
	
	public void prepareCoffee(CoffeeBuilder coffee) 
	{
		 coffee.addMilk();
		 coffee.addCream();
		 coffee.addSugar();
		 coffee.addCoffee();
		 
	}
	
}
