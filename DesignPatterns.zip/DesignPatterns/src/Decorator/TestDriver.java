package Decorator;

public class TestDriver {
	public static void drawFrame_client(ImageFrame f)
	{
		f.drawTopBorder();
		f.drawLeftBorder();
		f.drawRightBorder();
		f.drawBottomBorder();
		
	}
	
	public static void main(String[] args) {
		RegularFrame f = new RegularFrame();
			// configuration
			f.setLineThinkness(10);
		drawFrame_client(f);
		System.out.println("=====================================");
		
		// wanted to add a shadow border
		drawFrame_client(new ShadowBorder(f));
	}
}
