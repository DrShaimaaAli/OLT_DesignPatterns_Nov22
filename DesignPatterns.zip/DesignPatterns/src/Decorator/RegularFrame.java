package Decorator;

public class RegularFrame extends ImageFrame {
	private int lineThinkness;

	int getLineThinkness() {
		return lineThinkness;
	}

	void setLineThinkness(int lineThinkness) {
		this.lineThinkness = lineThinkness;
	}
	
	 void drawTopBorder()
	 {
		 System.out.println("Top Border Drawn");
	 }
	 void drawBottomBorder()
	 {
		 System.out.println("Top Bottom Drawn");
	 }
	 void drawLeftBorder()
	 {
		 System.out.println("Top Left Drawn");
	 }
	 void drawRightBorder()
	 {
		 System.out.println("Top Right Drawn");
	 }
}
