package Decorator;

public class ShadowBorder extends ImageFrame {
	  ImageFrame frame;
	  ShadowBorder(ImageFrame frame)
	  {
		  this.frame = frame;
	  }
	
	 void drawTopBorder() {
		 frame.drawTopBorder();
	 }
	 void drawBottomBorder() {
		 frame.drawBottomBorder();
		 System.out.println("Add Shadow");
	 }
	 void drawLeftBorder() {
		 frame.drawLeftBorder();
	 }
	 void drawRightBorder() {
		 frame.drawRightBorder();
		 System.out.println("Add Shadow");
	 }

}
