package Decorator;

public abstract class ImageFrame {

	abstract void drawTopBorder();
	abstract void drawBottomBorder();
	abstract void drawLeftBorder();
	abstract void drawRightBorder();
}
