package State;

public class TCPConnection {
	TCPConnectionState state;
	
	public void open() {
		state.open();
	}
	
	public void close() {
			state.close();
		}
	
}
