package State;

public abstract class TCPConnectionState {
	abstract public void open();
	abstract public void close();
}
