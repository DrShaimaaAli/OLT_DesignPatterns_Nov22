package ChainOfResponsibilities;

public class SpamHandler extends EmailHandler{

	public String processMessage(String emailMessage)
	{
		String emailType = ""; // logic to determine the type 
		
		if (emailType.equals("spam"))
		{
			// logic to handle spam email
			return "Moved to the spam folder";
		}
		else
			if (getSuccessor() == null)
				return getSuccessor().processMessage(emailMessage);
			else
				return "Request cannot be handled";
	}

}
