package ChainOfResponsibilities;

public abstract class EmailHandler {
	private EmailHandler successor;
	
	abstract public String processMessage(String emailMessage);

	EmailHandler getSuccessor() {
		return successor;
	}

	void setSuccessor(EmailHandler successor) {
		this.successor = successor;
	}
	
}
