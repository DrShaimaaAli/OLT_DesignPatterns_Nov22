package ChainOfResponsibilities;

public class ComplaintHandler extends EmailHandler{

	public String processMessage(String emailMessage)
	{
		String emailType = ""; // logic to determine the type 
		
		if (emailType.equals("complaint"))
		{
			//logic to handle handle complaint email
			return "Forwarded to the customer services";
		}
		else
			if (getSuccessor() == null)
				return getSuccessor().processMessage(emailMessage);
			else
				return "Request cannot be handled";
	}

}
