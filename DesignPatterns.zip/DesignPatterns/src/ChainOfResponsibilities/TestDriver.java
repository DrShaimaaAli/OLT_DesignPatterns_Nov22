package ChainOfResponsibilities;

public class TestDriver {
	public static void main(String[] args) {
		// configure the chain
		FanHandler fan = new FanHandler();
		SpamHandler spam = new SpamHandler();
		ComplaintHandler complaint = new ComplaintHandler();
		
		fan.setSuccessor(spam);
		spam.setSuccessor(complaint);
		
		// configure the client
		EmailReciever client = new EmailReciever();
		client.setHandler(fan);
		
		client.handleEmail("Message");
		
	}

}
