package ChainOfResponsibilities;

public class FanHandler extends EmailHandler{

	public String processMessage(String emailMessage)
	{
		String emailType = ""; // logic to determine the type 
		
		if (emailType.equals("fan"))
		{
			//logic to handle handle fan email
			return "Posted as a testimony";
		}
		else
			if (getSuccessor() != null)
				return getSuccessor().processMessage(emailMessage);
			else
				return "Request cannot be handled";
	}
}
