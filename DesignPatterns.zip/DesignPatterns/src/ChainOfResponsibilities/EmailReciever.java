package ChainOfResponsibilities;

public class EmailReciever {
	private EmailHandler handler;
	
	public void recieveEmail(String emailMessage)
	{
		String msg = handleEmail(emailMessage);
		
		System.out.println(msg);
	}
	
	public String handleEmail(String emailMessage)
	{
		return handler.processMessage(emailMessage); 
		/*
	    String emailType = ""; // logic to detect email type
	    
		
		if (emailType.equals("spam") )
		{
			// logic to handle spam email
			confirmationMessage = "Moved to the spam folder";
		}
		else if (emailType.equals("fan"))
		{
			//logic to handle handle fan email
			confirmationMessage = "Posted as a testimony";
		}
		else if (emailType.equals("complaint"))
		{
			//logic to handle handle complaint email
			confirmationMessage = "Forwarded to the customer services";
		}
		else if (emailType.equals("newLoc"))
		{
			//logic to handle handle newLoc email
		    confirmationMessage = "Forwarded to suggestions and planning department";
		}
		else
		{
			// default handling logic
		    confirmationMessage = "Left in the inbox";
		}
		*/
		
	}

	EmailHandler getHandler() {
		return handler;
	}

	void setHandler(EmailHandler handler) {
		this.handler = handler;
	}
}